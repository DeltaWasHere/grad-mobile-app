package com.example.completionistguild;

import android.content.Context;
import android.webkit.JavascriptInterface;

import com.example.completionistguild.model.UserAuthData;
import com.google.gson.Gson;
import com.google.gson.JsonParser;

class MyJavaScriptInterface {

    private Context ctx;

    MyJavaScriptInterface(Context ctx) {
        this.ctx = ctx;
    }

    @JavascriptInterface
    public void showHTML(String html) {
        Gson g = new Gson();
        UserAuthData data =g.fromJson(html, UserAuthData.class);

        System.out.println("ID: "+data.getSteamid()+ " avatar: "+ data.getAvatar());
    }
}