package com.example.completionistguild.callInterface;
import com.example.completionistguild.model.UserAuthData;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Url;

public interface apiCalls {

    @GET
    Call<List<UserAuthData>> getUserAuthData(@Url String url);


}
