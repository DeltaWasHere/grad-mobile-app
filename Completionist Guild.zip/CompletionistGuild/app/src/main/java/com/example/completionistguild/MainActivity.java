package com.example.completionistguild;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.completionistguild.callInterface.apiCalls;
import com.example.completionistguild.profile.ProfileFragment;
import com.example.completionistguild.profile.SearchProfileFragment;
import com.google.android.material.navigation.NavigationView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    DrawerLayout mDrawerLayout;
    NavigationView mNavigationView;
    ImageButton homeButton;
    Toolbar mToolbar;
    ActionBarDrawerToggle toggle;
    TextView authButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDrawerLayout = findViewById(R.id.drawer_layout);
        mNavigationView = findViewById(R.id.nav_view);
        mToolbar = findViewById(R.id.toolbar);
        homeButton = mNavigationView.findViewById(R.id.home);
        authButton = mToolbar.findViewById(R.id.auth);

        homeButton.setOnClickListener(this);
        authButton.setOnClickListener(this);

        setSupportActionBar(mToolbar);

        toggle = setUpDrawerToggle();
        mDrawerLayout.addDrawerListener(toggle);

        mNavigationView.setNavigationItemSelectedListener(this);

    }

    private ActionBarDrawerToggle setUpDrawerToggle() {
        return new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        toggle.syncState();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        selectItemNav(item);

        return true;
    }

    private void selectItemNav(MenuItem item) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        switch (item.getItemId()) {
            case R.id.nav_profile:
                ft.replace(R.id.content, new ProfileFragment()).commit();
                break;
            case R.id.nav_chart:

                break;
            case R.id.nav_search_game:

                break;
            case R.id.nav_search_user:
                ft.replace(R.id.content, new SearchProfileFragment()).commit();
                break;
            case R.id.nav_trade:

                break;
            case R.id.nav_report:

                break;



        }
        setTitle(item.getTitle());
        mDrawerLayout.closeDrawers();
    }

    @Override
    public void onClick(View view) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        switch (view.getId()){
            case R.id.home:
                ft.replace(R.id.content, new HomeFragment()).commit();
                mDrawerLayout.closeDrawers();
                break;

            case R.id.auth:
                doTheauth();
                break;
        }

    }

    private void doTheauth() {
        Intent intent = new Intent(this, AuthWindow.class);
        startActivity(intent);
    }
}