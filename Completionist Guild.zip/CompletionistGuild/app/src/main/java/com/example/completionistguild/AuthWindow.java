package com.example.completionistguild;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.completionistguild.callInterface.apiCalls;
import com.example.completionistguild.model.UserAuthData;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AuthWindow extends AppCompatActivity {

    WebView mWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth_window);

        mWebView = findViewById(R.id.webView);

        WebSettings mWebSettings = mWebView.getSettings();
        mWebSettings.setJavaScriptEnabled(true);

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                mWebView.loadUrl(checkurl(url));
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url.contains("10.0.2.2:3000/auth/steam")) {

                    mWebView.loadUrl("javascript:HtmlViewer.showHTML" +
                            "(document.getElementsByTagName('body')[0].innerHTML);");
                }
            }
        });
        mWebView.addJavascriptInterface(new MyJavaScriptInterface(this), "HtmlViewer");

        mWebView.loadUrl(checkurl("http://localhost:3000/steam/auth"));
    }

    private String checkurl(String URL) {
        if (URL.contains("localhost:3000/steam/auth")) {

            URL = URL.replace("localhost:", "10.0.2.2:");

            mWebView.loadUrl(URL);
            return URL;
        } else if (URL.contains("localhost:3000/auth/steam")) {
            URL = URL.replace("localhost:", "10.0.2.2:");
            mWebView.loadUrl(URL);
        }
        return URL;

    }
}